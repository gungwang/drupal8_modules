<?php

namespace Drupal\webform_access;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Provides an interface defining a webform access type entity.
 */
interface WebformAccessTypeInterface extends ConfigEntityInterface {

}
