New releases of the Webform module for Drupal 8 with bugs fixes
and new features are released every month.

* For a full list of fixes in the latest release, visit:  
  https://www.drupal.org/project/webform/releases?api_version%5B%5D=7234 

* Read the Webform's API and feature change records which describe changes
  and its impact on site users, site builders, themers, and module developers  
  https://www.drupal.org/list-changes/webform/published?to_branch=8.x-5.x
